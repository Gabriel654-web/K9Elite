document.getElementById('formCadastro').addEventListener('submit', function(e) {
  e.preventDefault();
  alert('Inscrição enviada com sucesso!');
});
document.getElementById('listaSelecionados').innerText = 'Nenhum jogador aprovado ainda.';